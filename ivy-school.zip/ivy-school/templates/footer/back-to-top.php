<?php
/**
 * Back To Top
 */
?>

<i data-fip-value="ion-ios-arrow-thin-up" class="ion-ios-arrow-thin-up"></i>